package xmazegift

import "strings"

const (
	FLAG_0     = "FLAG_0_..."
	FLAG_1     = "FLAG_1_..."
	FLAG_2     = "FLAG_2_..."
	FLAG_3     = "FLAG_3_..."
	FLAG_4     = "FLAG_4_..."
	EASTER_EGG = "..."
)

func checkEasterEgg(moves string) bool {
	return strings.Contains(moves, EASTER_EGG)
}
