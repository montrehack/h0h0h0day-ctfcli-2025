const cookieParser = require('cookie-parser');
const { engine } = require('express-handlebars');

const {
    genNiceKidsListToken,
    canViewList,
    canUpdateListCriteria
} = require('./tokens');

const express = require('express');
const app = express();
const port = 3000;

var nice_kids_threshold = 72;

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views')
app.use('/static', express.static('static'))
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

app.get('/', function(req, res){
    var token = req.cookies.token;
    if (!token) {
        token = genNiceKidsListToken();
        res.cookie('token', token)
    }
    
    res.render('home', {msg: req.query.msg});
});

app.get('/list', function(req, res){
    var token = req.cookies.token;
    var error;
    try {
        if (!token || !canViewList(token))
            error = 'Seuls les lutins et le Père Noël peuvent voir la liste des enfants sages...';
    } catch(err) {
        error = 'Seuls les lutins et le Père Noël peuvent voir la liste des enfants sages...';
    }
    
    if (error)
        res.redirect('/?msg=' + encodeURIComponent(error));
    else
        res.render('list', {threshold: nice_kids_threshold, msg: req.query.msg});
});

app.post('/update', function(req, res) {
    var threshold = req.body.threshold;
    var msg;
    try {
        if (threshold && isNumeric(threshold) && canUpdateListCriteria(req.cookies.token)) {
            nice_kids_threshold = parseInt(threshold);
            msg = 'FLAG-placeholder';
        } else {
            msg = 'Seul le Père Noël peut mettre à jour le seuil de sagesse...';
        }
    } catch(err) {
        msg = 'Seul le Père Noël peut mettre à jour le seuil de sagesse...';
    }

    res.redirect('/list?msg=' + encodeURIComponent(msg));
});

app.listen(port, () => {
  console.log(`App listening on port ${port}`)
})

function isNumeric(num){
  return !isNaN(+num)
}

