const { loadEnvFile } = require('node:process');
const crypto = require('crypto');
const util = require('util');

const VIEW_RIGHT = 'view';
const UPDATE_RIGHT = 'I am Santa, I do whatever I want!';
const VIEWING_RIGHTS = [VIEW_RIGHT, UPDATE_RIGHT];

loadEnvFile('./config.env');
const keys = {
    santa_key : {
        rsa_key: process.env.SANTA_RSA_KEY,
        hmac_key: process.env.SANTA_HMAC_KEY
    },
    elf_key : {
        rsa_key: process.env.ELF_RSA_KEY,
        hmac_key: process.env.ELF_HMAC_KEY
    }
};

const instanceSalt = crypto.randomBytes(32).toString('hex');

function getRandomInt(min, max) {
    max += 1; // max is otherwise exclusive
    return Math.floor(Math.random() * (max - min) + min);
}

function toBase64Url(buf) {
    if (typeof buf === 'string')
      buf = Buffer.from(buf);
  
    return buf.toString('base64url');
}

function fromBase64Url(s) {
    return Buffer.from(s, 'base64url');
}

function toSignable(header, payload) {
    var b64Header = toBase64Url(JSON.stringify(header));
    var b64Payload = toBase64Url(JSON.stringify(payload));
    return util.format('%s.%s', b64Header, b64Payload);
}

function toJwtStr(header, payload, signature) {
    var b64Signature = toBase64Url(signature);
    return util.format('%s.%s', toSignable(header, payload), b64Signature);
}

function parse(jwtStr) {
    var parts = jwtStr.split('.');
    if (parts.length != 3)
        return null;

    var jwt = {
        header : JSON.parse(fromBase64Url(parts[0])),
        payload : JSON.parse(fromBase64Url(parts[1])),
        signature : parts[2]
    };
    return jwt;
}

function resolveKey(jwt) {
    if (!jwt) return null;

    if (typeof (jwt.header.kid) !== 'string' || !keys[jwt.header.kid]) {
        throw new Error("That key doesn't exist");
    }
    return keys[jwt.header.kid];
}

function sign(header, payload, key) {
    var alg = header.alg;
    var toSign = toSignable(header, payload);
    var signature;
    switch(alg) {
        case 'HS256':
            var key = crypto.pbkdf2Sync(
                instanceSalt + key.hmac_key,
                'santa_wants_a_strong_derived_key',
                100000, 128, 'sha256'
            );

            var hmac = crypto.createHmac('sha256', key);
            hmac.update(toSign);
            signature = hmac.digest();
            break;
        case 'RS256':
        default:
            throw new Error('Only supporting HS256 for now...');
            break;
    }
    return toJwtStr(header, payload, signature);
}

function verify(jwt) {
    jwt = parse(jwt);

    var key = resolveKey(jwt);
    var computedJwt = sign(jwt.header, jwt.payload, key);
    var computedSig = parse(computedJwt).signature;
    return crypto.timingSafeEqual(Buffer.from(jwt.signature), Buffer.from(computedSig));
}

function genNiceKidsListToken() {
    var header = {
        alg : 'HS256',
        kid : 'elf_key' // Le Père Noël est bien capable de faire son token lui-même !
    };
    
    var payload = {
        exp : 1766638800,
        name: 'Lutin ' + getRandomInt(1000, 100000), // Pour le Père Noël, on est juste un numéro...
        securityQuestions : {
            favouriteReindeer : 'Commit',
            vpnProviderOfChoice : 'North "Pole" VPN',
            favouriteCar : 'Santa Fe',
            favouriteGuitarPlayer : 'Santana'
        },
        santaListRights : VIEW_RIGHT,
        salt : instanceSalt
    };
     
    return sign(header, payload, keys[header.kid]);
}

function canViewList(jwt) {
    if (!verify(jwt))
        return false;

    jwt = parse(jwt);
    if (Date.now() / 1000 > jwt.payload.exp ||
        VIEWING_RIGHTS.indexOf(jwt.payload.santaListRights) == -1)
        return false;
    
    return true;
}

function canUpdateListCriteria(jwt) {
    if (!verify(jwt))
        return false;
    
    jwt = parse(jwt);
    if (Date.now() / 1000 > jwt.payload.exp ||
        jwt.payload.santaListRights !== UPDATE_RIGHT ||
        jwt.payload.name !== 'Santa')
        return false;
    
    return true;
}

exports.genNiceKidsListToken = genNiceKidsListToken;
exports.canViewList = canViewList;
exports.canUpdateListCriteria = canUpdateListCriteria;

